import Vue from 'vue'

// 中央事件总线
export const Bus = new Vue()